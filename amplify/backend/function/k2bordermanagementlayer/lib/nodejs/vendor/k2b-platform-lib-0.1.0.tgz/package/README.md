# @k2b/platform-lib

Backend code shared by every K2B service's Lambda layer. It replaces the per-repo copies that each service used to carry, so a fix is made once (delivery plan L0.1).

The plan is for actor resolution (A1.6) and the price resolver (P3.6) to live here. Version 0.1.0 holds the modules that were already identical across layers:

| Module | Exports |
|---|---|
| `environment` | `requireEnvironment`, `ALLOWED_ENVIRONMENTS` (F0.6) |
| `sqlColumns` | `assertSafeColumns`, `pickColumns` (F0.5) |
| `cognitoExtractor` | `extractAndInjectCognitoAuth`, `extractUserSubFromAuthProvider` (F0.A3) |
| `caseConverter` | `toSnakeCase`, `toCamelCase` |

There are no runtime dependencies. Keep it that way where possible, because every layer pays for them.

## How services get it

CodeBuild gets each repo as a zip without GitHub credentials, so services can't install from this repo directly. Instead, each release is a tarball that the service commits:

```
<layer>/lib/nodejs/vendor/k2b-platform-lib-<version>.tgz
<layer>/lib/nodejs/package.json   "@k2b/platform-lib": "file:vendor/k2b-platform-lib-<version>.tgz"
```

The layer's lockfile records the tarball's hash, so `npm ci` fails if the file is replaced without a version bump.

The layer keeps its old `utils/<module>.js` files as one-line re-exports (`module.exports = require("@k2b/platform-lib/<module>")`). Handlers keep importing `/opt/nodejs/utils/...`. In Lambda the package resolves from `/opt/nodejs/node_modules`.

## Releasing

1. Change the code and tests, then bump `version` in `package.json` (semver) and add a `CHANGELOG.md` entry.
2. `bash scripts/pack.sh` runs the tests and writes `dist/k2b-platform-lib-<version>.tgz`.
3. Commit and tag `v<version>` here.
4. For each service layer: `bash scripts/install-into.sh <path to layer lib/nodejs>`, run that service's tests, and commit `vendor/`, `package.json` and `package-lock.json` there.

Services can move to a new version one at a time. A layer only changes when its tarball does.

## Tests

```bash
npm ci
npm test
```

## Consumers

| Service | Layer | Version |
|---|---|---|
| `k2b-order-management` | `k2bordermanagementlayer` | 0.1.0 |
