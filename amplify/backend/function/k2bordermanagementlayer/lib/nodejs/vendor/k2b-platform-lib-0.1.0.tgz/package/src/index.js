/**
 * @k2b/platform-lib: backend code shared by every K2B service layer.
 *
 * Layers re-export these modules from their own utils/ files, so handlers keep
 * importing from /opt/nodejs/utils/... and don't need to know about the package.
 */

module.exports = {
  ...require("./environment"),
  ...require("./sqlColumns"),
  ...require("./caseConverter"),
  ...require("./cognitoExtractor"),
};
