-- Up Migration
-- D0.2 follow-up: brings the existing dev and prod schemas in line with the baseline's naming,
-- and fixes the drift found in V0.2 (docs/new-direction/09-schema-drift.md).

-- 1. Object names that embed the schema (idx_dev_orders_status, uq_prod_admin_profile) lose the
--    schema token, so every environment uses the same names. No-op on a schema built from the
--    baseline. Constraints first: renaming a constraint also renames its index.
DO $$
DECLARE
  s text := current_schema();
  token text := '_' || current_schema() || '_';
  r record;
BEGIN
  FOR r IN
    SELECT cl.relname AS table_name, con.conname AS name
    FROM pg_constraint con
    JOIN pg_class cl ON cl.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = cl.relnamespace
    WHERE n.nspname = s AND position(token IN con.conname) > 0
  LOOP
    EXECUTE format('ALTER TABLE %I RENAME CONSTRAINT %I TO %I', r.table_name, r.name, replace(r.name, token, '_'));
  END LOOP;

  FOR r IN
    SELECT i.relname AS name
    FROM pg_index x
    JOIN pg_class i ON i.oid = x.indexrelid
    JOIN pg_namespace n ON n.oid = i.relnamespace
    WHERE n.nspname = s AND position(token IN i.relname) > 0
      AND NOT EXISTS (SELECT 1 FROM pg_constraint k WHERE k.conindid = x.indexrelid)
  LOOP
    EXECUTE format('ALTER INDEX %I RENAME TO %I', r.name, replace(r.name, token, '_'));
  END LOOP;
END $$;

-- 2. admin_users unique constraints: the repo SQL's names (V0.2 difference 2).
ALTER TABLE admin_users RENAME CONSTRAINT admin_users_email_key TO uq_admin_users_email;
ALTER TABLE admin_users RENAME CONSTRAINT admin_users_cognito_sub_key TO uq_admin_users_cognito_sub;

-- 3. The missing foreign keys to tenants (V0.2 difference 1). No orphan rows existed on 17 Nov.
ALTER TABLE configurations
  ADD CONSTRAINT fk_configurations_tenant_id FOREIGN KEY (tenant_id) REFERENCES tenants (id) ON DELETE CASCADE;
ALTER TABLE tenant_addresses
  ADD CONSTRAINT fk_tenant_addresses_tenant_id FOREIGN KEY (tenant_id) REFERENCES tenants (id) ON DELETE CASCADE;
