# k2b-db-migrations

Versioned, forward-only Postgres migrations for every K2B service (plan task D0.1). One history for the whole database, applied per environment schema.

## How it works

- **Tool:** [node-pg-migrate](https://github.com/salsita/node-pg-migrate) 9, plain `.sql` files in `migrations/`.
- **Schemas:** `k2bdb` holds `dev` and `prod` schemas. Migrations use unqualified names. The runner sets `search_path` to the target schema, then `public`.
- **History:** each schema records applied migrations in its own `schema_migrations` table.
- **Safety:**
  - An advisory lock stops overlapping runs.
  - A run is one transaction, so a failure applies nothing.
  - An older file added after newer ones ran is refused.
  - A missing schema is an error, never created.
- **Pipelines** (the shared `k2b-custom-build-project`, `buildspec.yml`):

  | Pipeline | Branch | Schema |
  |---|---|---|
  | `k2b-db-migrations-dev` | `main` | `dev` |
  | `k2b-db-migrations-prod` | `v_1_0_0` | `prod` (ships with the batch release) |

  Each run executes the tests first, then a dry run, then the migrations.
- **Credentials:** the `adminPassword` secret the Lambdas use today (override with `DB_SECRET_ID`). F0.7 replaces it with a dedicated migration user.

## Writing a migration

```bash
npm run new -- add-organisations    # creates migrations/<UTC timestamp>_add-organisations.sql
```

Rules (checked by `test/conventions.test.mjs`):
- Start with `-- Up Migration`. There is no Down section.
- Don't use `dev.` or `prod.` prefixes.
- Don't use `BEGIN`/`COMMIT`.
- Never edit a migration that has run in dev. Write a new one.

Statements that can't run in a transaction (such as `CREATE INDEX CONCURRENTLY`) aren't supported yet.

## Running and testing

```bash
npm ci
npm test       # starts a throwaway Postgres 18.3 (same version as RDS) on a free port
DATABASE_URL=postgres://user:pass@localhost:5432/db npm run migrate -- --env dev --dry-run
```

Don't run `migrate` against `k2bdb` from a laptop. The pipeline is the only writer.

## Integration-test database (T0.2)

Services test their real database code against a throwaway Postgres built from these migrations:

```js
import { startTestDatabase } from "@k2b/db-migrations/testing";
const db = await startTestDatabase(); // Postgres 18.3 on a free port, every migration applied to "dev"
process.env.ENVIRONMENT = db.schema;  // the services use ENVIRONMENT as the schema name
await createOrder(db.pool, { ... });  // real service code, real tables
await db.reset();                      // empty every table between tests
await db.stop();
```

- **Delivery:** services include it the same way as `@k2b/platform-lib`, as a committed tarball. It goes in a **repo-root** `package.json` used only for tests, never a Lambda layer, because the bundled Postgres binary is about 100 MB.
- **CI:** `scripts/ci-test.sh` already runs the repo-root `npm test`.
- **Current consumers:** order-management and user-management, under `test/integration/`.

**Releasing a new version** (after adding migrations a service's tests need):

```bash
npm version minor --no-git-tag-version && npm run pack   # dist/k2b-db-migrations-<ver>.tgz
# in each consumer: replace vendor/k2b-db-migrations-*.tgz, update the file: path in package.json, npm install
```

## Baseline (D0.2)

`migrations/20261117000000_baseline.sql` is the whole schema as it stood on 17 Nov 2026. `scripts/generate-baseline.mjs` generated it from a read-only snapshot of the real database, which is kept as `test/fixtures/baseline-schema.json`.

- **Existing schemas adopt it.** If every baseline table already exists, the runner records the baseline as applied without running it, and logs it as `(adopted: schema already existed)`. A schema with only some of the tables is refused.
- **Empty schemas run it for real.** Tests prove the result matches the real schema exactly.
- **Names are schema-neutral:** `idx_orders_status`, not `idx_dev_orders_status`. `20261117000100_converge-existing-schemas.sql` renames the old schema-named objects in existing schemas. It also adds the two foreign keys found missing in V0.2.
- **Never edit or regenerate the baseline.** Change the schema with new migrations.

The per-service SQL in `*/scripts/` is history now.

Read-only tools: `scripts/inspect-schema.mjs` snapshots the real schemas, and `scripts/compare-repo-sql.mjs` compares the old repo SQL with a snapshot (V0.2).
