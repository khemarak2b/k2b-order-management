// Starts a throwaway Postgres 18.3 (same major and minor as RDS k2bdb) on a free local port.
import { mkdtempSync, rmSync, chmodSync } from "node:fs";
import { tmpdir, userInfo } from "node:os";
import { join } from "node:path";
import { createServer } from "node:net";
import EmbeddedPostgres from "embedded-postgres";
import pg from "pg";

async function freePort() {
  return new Promise((resolve, reject) => {
    const srv = createServer();
    srv.unref();
    srv.on("error", reject);
    srv.listen(0, "127.0.0.1", () => {
      const { port } = srv.address();
      srv.close(() => resolve(port));
    });
  });
}

export async function startPostgres() {
  const dir = mkdtempSync(join(tmpdir(), "k2b-pg-"));
  const isRoot = process.platform !== "win32" && userInfo().uid === 0;
  if (isRoot) chmodSync(dir, 0o777); // CodeBuild runs as root; Postgres runs as a created "postgres" user
  const port = await freePort();
  const password = "test-only";

  const server = new EmbeddedPostgres({
    databaseDir: join(dir, "data"),
    port,
    user: "postgres",
    password,
    persistent: false,
    // Postgres 18's default I/O worker processes outlive stop() on Windows and keep the test run open.
    postgresFlags: ["-c", "io_method=sync", "-c", "fsync=off"],
    createPostgresUser: isRoot,
    onLog: () => {},
    onError: () => {},
  });
  await server.initialise();
  await server.start();

  let dbCounter = 0;
  return {
    port,
    /** Creates a fresh database with empty dev and prod schemas, like k2bdb. */
    async freshDatabase() {
      const name = `k2b_test_${++dbCounter}`;
      await server.createDatabase(name);
      const url = `postgres://postgres:${password}@127.0.0.1:${port}/${name}`;
      await query(url, "CREATE SCHEMA dev; CREATE SCHEMA prod;");
      return url;
    },
    async stop() {
      await server.stop();
      rmSync(dir, { recursive: true, force: true });
    },
  };
}

export async function query(url, sql, params) {
  const client = new pg.Client({ connectionString: url });
  await client.connect();
  try {
    return await client.query(sql, params);
  } finally {
    await client.end();
  }
}

export async function tablesIn(url, schema) {
  const { rows } = await query(
    url,
    "SELECT table_name FROM information_schema.tables WHERE table_schema = $1 ORDER BY table_name",
    [schema],
  );
  return rows.map((r) => r.table_name);
}
