// T0.2: integration-test harness for the services.
//
//   import { startTestDatabase } from "@k2b/db-migrations/testing";
//   const db = await startTestDatabase();      // Postgres 18.3 with every migration applied to "dev"
//   process.env.ENVIRONMENT = db.schema;      // the services use ENVIRONMENT as the schema name
//   await createOrder(db.pool, {...});        // real service code, real tables
//   await db.reset();                          // empty every table between tests
//   await db.stop();
//
// The schema comes from this package's migrations, so tests run against exactly what the
// pipelines deploy. Nothing here ever connects to RDS.

import pg from "pg";
import { startPostgres } from "./embeddedPostgres.mjs";
import { runMigrations, MIGRATIONS_TABLE } from "./runner.mjs";

export async function startTestDatabase({ schema = "dev" } = {}) {
  const server = await startPostgres();
  try {
    const url = await server.freshDatabase();
    const setup = new pg.Client({ connectionString: url });
    await setup.connect();
    await setup.query("CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public");
    await setup.end();
    const migrations = await runMigrations({ connection: url, env: schema });

    const pool = new pg.Pool({ connectionString: url, max: 5 });
    const tables = (
      await pool.query(
        `SELECT tablename FROM pg_tables WHERE schemaname = $1 AND tablename <> $2 ORDER BY tablename`,
        [schema, MIGRATIONS_TABLE],
      )
    ).rows.map((r) => `${pg.escapeIdentifier(schema)}.${pg.escapeIdentifier(r.tablename)}`);

    return {
      url,
      schema,
      pool,
      migrations,
      /** Runs one query on the pool. */
      query: (sql, params) => pool.query(sql, params),
      /** Empties every table (keeping the schema and migration history) and restarts ids at 1. */
      async reset() {
        await pool.query(`TRUNCATE ${tables.join(", ")} RESTART IDENTITY CASCADE`);
      },
      async stop() {
        await pool.end();
        await server.stop();
      },
    };
  } catch (err) {
    await server.stop();
    throw err;
  }
}
