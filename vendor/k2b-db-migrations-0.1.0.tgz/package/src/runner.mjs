import { readFileSync, existsSync } from "node:fs";
import { join } from "node:path";
import { fileURLToPath } from "node:url";
import pg from "pg";
import { runner } from "node-pg-migrate";

export const ENVIRONMENTS = Object.freeze(["dev", "prod"]);
export const MIGRATIONS_DIR = fileURLToPath(new URL("../migrations", import.meta.url));
export const MIGRATIONS_TABLE = "schema_migrations";
// D0.2: the schema as it stood before this repo existed. Must sort first in migrations/.
export const BASELINE_MIGRATION = "20261117000000_baseline";
export const ADOPTED_SUFFIX = " (adopted: schema already existed)";

export function assertEnvironment(env) {
  if (!ENVIRONMENTS.includes(env)) {
    throw new Error(`--env must be one of ${ENVIRONMENTS.join(", ")} (got ${JSON.stringify(env)})`);
  }
}

/** Table names the baseline creates, read from its CREATE TABLE statements. */
export function baselineTables(dir = MIGRATIONS_DIR) {
  const file = join(dir, `${BASELINE_MIGRATION}.sql`);
  if (!existsSync(file)) return null;
  return [...readFileSync(file, "utf8").matchAll(/^CREATE TABLE "([^"]+)"/gm)].map((m) => m[1]).sort();
}

/**
 * Decides whether an existing schema should adopt the baseline instead of running it:
 *   - "none":  baseline already recorded, or the schema has none of its tables (run it for real)
 *   - "adopt": every baseline table already exists (record it as applied without running it)
 * A schema holding only some of the tables is an error, so a half-built schema is never papered over.
 */
export async function baselineAction(connection, env, dir = MIGRATIONS_DIR) {
  const expected = baselineTables(dir);
  if (!expected) return "none";

  const client = new pg.Client(typeof connection === "string" ? { connectionString: connection } : connection);
  await client.connect();
  try {
    const recorded = await client.query(
      `SELECT to_regclass(format('%I.%I', $1::text, $2::text)) IS NOT NULL AS has_table`,
      [env, MIGRATIONS_TABLE],
    );
    if (recorded.rows[0].has_table) {
      const r = await client.query(`SELECT 1 FROM ${pg.escapeIdentifier(env)}.${MIGRATIONS_TABLE} WHERE name = $1`, [
        BASELINE_MIGRATION,
      ]);
      if (r.rowCount > 0) return "none";
    }
    const existing = new Set(
      (
        await client.query(
          `SELECT c.relname FROM pg_class c JOIN pg_namespace n ON n.oid = c.relnamespace
           WHERE n.nspname = $1 AND c.relkind IN ('r','p')`,
          [env],
        )
      ).rows.map((r) => r.relname),
    );
    const present = expected.filter((t) => existing.has(t));
    if (present.length === 0) return "none";
    if (present.length === expected.length) return "adopt";
    const missing = expected.filter((t) => !existing.has(t));
    throw new Error(
      `Schema "${env}" has ${present.length} of the ${expected.length} baseline tables (missing: ${missing.join(", ")}). ` +
        `Refusing to adopt or run the baseline on a partly built schema.`,
    );
  } finally {
    await client.end();
  }
}

/**
 * Applies every pending migration to one environment schema and returns the names applied.
 *
 * Migration files use unqualified table names. The runner sets search_path to the
 * environment schema first (so CREATE TABLE lands there), then public (so extension
 * functions like gen_random_uuid() resolve). Each environment records its own history in
 * <env>.schema_migrations, and an advisory lock stops two runs from overlapping.
 *
 * An existing schema adopts the baseline: it is recorded as applied without running, and
 * reported as "<name> (adopted: schema already existed)".
 */
export async function runMigrations({ connection, env, dryRun = false, dir = MIGRATIONS_DIR, log = () => {} }) {
  assertEnvironment(env);

  const options = {
    databaseUrl: connection,
    dir,
    direction: "up",
    schema: [env, "public"],
    createSchema: false, // dev and prod schemas already exist; a typo must fail, not create a schema
    migrationsSchema: env,
    migrationsTable: MIGRATIONS_TABLE,
    ignorePattern: "(?!.*\\.sql$).*", // load .sql files only (skips README.md and dotfiles)
    checkOrder: true, // refuse to run if an older file appears after newer ones were applied
    singleTransaction: true, // all pending migrations commit together or not at all
    verbose: false,
    log,
  };

  const action = await baselineAction(connection, env, dir);
  if (action === "adopt" && !dryRun) {
    // Record only the baseline (it sorts first) without running it.
    await runner({ ...options, fake: true, count: 1 });
  }

  const applied = (await runner({ ...options, dryRun })).map((m) => m.name);
  if (action !== "adopt") return applied;
  return dryRun
    ? applied.map((n) => (n === BASELINE_MIGRATION ? n + ADOPTED_SUFFIX : n))
    : [BASELINE_MIGRATION + ADOPTED_SUFFIX, ...applied];
}
