import { SecretsManagerClient, GetSecretValueCommand } from "@aws-sdk/client-secrets-manager";

const DEFAULT_SECRET_ID = "adminPassword";

/**
 * Returns a pg ClientConfig.
 *
 * DATABASE_URL wins (local runs and tests). Otherwise the credentials come from the
 * Secrets Manager secret in DB_SECRET_ID, with the same shape and TLS settings the
 * service layers use today. F0.7 replaces both the shared secret and the TLS setting.
 */
export async function resolveConnection(env, { fetchSecret = fetchSecretFromAws } = {}) {
  if (env.DATABASE_URL) {
    return { connectionString: env.DATABASE_URL };
  }

  const secretId = env.DB_SECRET_ID || DEFAULT_SECRET_ID;
  const creds = await fetchSecret(secretId, env.AWS_REGION || env.DEPLOYMENT_REGION);
  for (const key of ["host", "username", "password", "dbname"]) {
    if (!creds[key]) throw new Error(`Secret ${secretId} has no "${key}"`);
  }

  return {
    host: creds.host,
    port: Number(creds.port) || 5432,
    user: creds.username,
    password: creds.password,
    database: creds.dbname,
    ssl: { rejectUnauthorized: false }, // matches the service layers until F0.7
    connectionTimeoutMillis: 10000,
  };
}

async function fetchSecretFromAws(secretId, region) {
  const client = new SecretsManagerClient(region ? { region } : {});
  const res = await client.send(new GetSecretValueCommand({ SecretId: secretId }));
  return JSON.parse(res.SecretString);
}
