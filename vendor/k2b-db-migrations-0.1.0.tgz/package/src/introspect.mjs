// Read-only snapshot of one schema's structure, normalised so two schemas (dev vs prod,
// or real vs rebuilt-from-SQL) can be compared. The schema name is replaced by "$S" in
// every definition, and nothing here reads table data except planner row estimates.

const Q = {
  tables: `
    SELECT c.relname AS name, c.relkind AS kind, c.reltuples::bigint AS est_rows
    FROM pg_class c JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE n.nspname = $1 AND c.relkind IN ('r','p','v','m','f')
    ORDER BY c.relname`,
  columns: `
    SELECT c.relname AS table, a.attnum AS pos, a.attname AS name,
           format_type(a.atttypid, a.atttypmod) AS type, a.attnotnull AS not_null,
           pg_get_expr(d.adbin, d.adrelid) AS default, a.attidentity AS identity, a.attgenerated AS generated
    FROM pg_attribute a
    JOIN pg_class c ON c.oid = a.attrelid JOIN pg_namespace n ON n.oid = c.relnamespace
    LEFT JOIN pg_attrdef d ON d.adrelid = a.attrelid AND d.adnum = a.attnum
    WHERE n.nspname = $1 AND c.relkind IN ('r','p','v','m','f') AND a.attnum > 0 AND NOT a.attisdropped
    ORDER BY c.relname, a.attnum`,
  constraints: `
    SELECT c.relname AS table, k.conname AS name, k.contype AS type, pg_get_constraintdef(k.oid, true) AS def
    FROM pg_constraint k JOIN pg_class c ON c.oid = k.conrelid JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE n.nspname = $1 AND k.contype IN ('p','u','f','c','x')
    ORDER BY c.relname, k.conname`,
  indexes: `
    SELECT t.relname AS table, i.relname AS name, pg_get_indexdef(i.oid) AS def
    FROM pg_index x
    JOIN pg_class i ON i.oid = x.indexrelid JOIN pg_class t ON t.oid = x.indrelid
    JOIN pg_namespace n ON n.oid = t.relnamespace
    WHERE n.nspname = $1 AND NOT EXISTS (SELECT 1 FROM pg_constraint k WHERE k.conindid = x.indexrelid)
    ORDER BY t.relname, i.relname`,
  sequences: `
    SELECT s.sequencename AS name, s.data_type::text AS type, s.increment_by AS increment
    FROM pg_sequences s WHERE s.schemaname = $1 ORDER BY s.sequencename`,
  views: `
    SELECT c.relname AS name, pg_get_viewdef(c.oid, true) AS def
    FROM pg_class c JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE n.nspname = $1 AND c.relkind IN ('v','m') ORDER BY c.relname`,
  triggers: `
    SELECT c.relname AS table, t.tgname AS name, pg_get_triggerdef(t.oid, true) AS def
    FROM pg_trigger t JOIN pg_class c ON c.oid = t.tgrelid JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE n.nspname = $1 AND NOT t.tgisinternal ORDER BY c.relname, t.tgname`,
  functions: `
    SELECT p.proname AS name, pg_get_function_identity_arguments(p.oid) AS args, pg_get_functiondef(p.oid) AS def
    FROM pg_proc p JOIN pg_namespace n ON n.oid = p.pronamespace
    WHERE n.nspname = $1 AND p.prokind IN ('f','p') ORDER BY p.proname, 2`,
  enums: `
    SELECT t.typname AS name, array_agg(e.enumlabel ORDER BY e.enumsortorder) AS labels
    FROM pg_type t JOIN pg_enum e ON e.enumtypid = t.oid JOIN pg_namespace n ON n.oid = t.typnamespace
    WHERE n.nspname = $1 GROUP BY t.typname ORDER BY t.typname`,
};

function normalise(value, schema) {
  if (typeof value !== "string") return value;
  value = value.replace(/\r\n/g, "\n"); // function bodies keep whatever line endings the script had
  // "dev".x and dev.x become $S.x (object names with the schema in them are handled below).
  const quoted = new RegExp(`"${schema}"\\.`, "g");
  const bare = new RegExp(`\\b${schema}\\.`, "g");
  return value.replace(quoted, "$S.").replace(bare, "$S.");
}

/** Returns { schema, tables: { name: {...} }, sequences, functions, enums } for one schema. */
export async function introspectSchema(client, schema) {
  const run = async (sql) => (await client.query(sql, [schema])).rows.map((r) => {
    const out = {};
    for (const [k, v] of Object.entries(r)) out[k] = normalise(v, schema);
    return out;
  });

  // One query at a time: a pg Client runs queries serially anyway.
  const results = [];
  for (const k of ["tables", "columns", "constraints", "indexes", "sequences", "views", "triggers", "functions", "enums"]) {
    results.push(await run(Q[k]));
  }
  const [tables, columns, constraints, indexes, sequences, views, triggers, functions, enums] = results;
  // Object names that embed the schema (idx_dev_orders_x, uq_prod_y, orders_dev_seq) compare as $S.
  const nameRe = new RegExp(`(^|_)${schema}(?=_|$)`, "g");
  for (const list of [constraints, indexes, sequences, triggers]) {
    for (const row of list) {
      row.name = row.name.replace(nameRe, "$1$S");
      if (typeof row.def === "string") row.def = row.def.replace(new RegExp(`\\b(\\w*_)?${schema}(_\\w*)?\\b`, "g"), (m) => m.replace(nameRe, "$1$S"));
    }
  }
  for (const c of columns) if (c.default) c.default = c.default.replace(new RegExp(`'(\\w*_)?${schema}(_\\w*)?'`, "g"), (m) => m.replace(nameRe, "$1$S"));

  const byTable = {};
  for (const t of tables) {
    byTable[t.name] = { kind: t.kind, est_rows: Number(t.est_rows), columns: {}, constraints: {}, indexes: {}, triggers: {} };
  }
  for (const c of columns) {
    byTable[c.table].columns[c.name] = {
      pos: c.pos, type: c.type, not_null: c.not_null, default: c.default,
      ...(c.identity ? { identity: c.identity } : {}), ...(c.generated ? { generated: c.generated } : {}),
    };
  }
  for (const k of constraints) byTable[k.table].constraints[k.name] = { type: k.type, def: k.def };
  for (const i of indexes) byTable[i.table].indexes[i.name] = i.def;
  for (const t of triggers) byTable[t.table].triggers[t.name] = t.def;
  for (const v of views) byTable[v.name].view = v.def;

  return {
    schema,
    tables: byTable,
    sequences: Object.fromEntries(sequences.map((s) => [s.name, { type: s.type, increment: Number(s.increment) }])),
    functions: Object.fromEntries(functions.map((f) => [`${f.name}(${f.args})`, f.def])),
    enums: Object.fromEntries(enums.map((e) => [e.name, e.labels])),
  };
}

/**
 * Drops the schema token from object names (idx_$S_orders_status -> idx_orders_status), the
 * naming the baseline uses. Returns a new snapshot; schema qualifiers ($S.) are kept.
 */
export function neutraliseNames(snapshot) {
  const strip = (s) => s.replace(/_\$S(?=_)/g, "").replace(/^\$S_/, "");
  const stripDef = (s) => s.replace(/\b(\w*)_\$S_(\w*)/g, "$1_$2");
  const out = structuredClone(snapshot);
  for (const t of Object.values(out.tables)) {
    for (const part of ["constraints", "indexes", "triggers"]) {
      t[part] = Object.fromEntries(
        Object.entries(t[part]).map(([n, v]) => [strip(n), typeof v === "string" ? stripDef(v) : { ...v, def: stripDef(v.def) }]),
      );
    }
  }
  return out;
}

/** Database-wide facts: schemas, extensions and server version. */
export async function introspectDatabase(client) {
  const schemas = (await client.query(`
    SELECT n.nspname AS name, count(c.oid) FILTER (WHERE c.relkind IN ('r','p')) AS tables
    FROM pg_namespace n LEFT JOIN pg_class c ON c.relnamespace = n.oid
    WHERE n.nspname NOT LIKE 'pg\\_%' AND n.nspname <> 'information_schema'
    GROUP BY n.nspname ORDER BY n.nspname`)).rows.map((r) => ({ name: r.name, tables: Number(r.tables) }));
  const extensions = (await client.query(
    `SELECT e.extname AS name, e.extversion AS version, n.nspname AS schema
     FROM pg_extension e JOIN pg_namespace n ON n.oid = e.extnamespace ORDER BY e.extname`,
  )).rows;
  const version = (await client.query("SHOW server_version")).rows[0].server_version;
  return { version, schemas, extensions };
}

/**
 * Lists differences between two snapshots as human-readable lines, grouped by table.
 * "a" and "b" are labels for the two sides (e.g. "dev" and "prod").
 */
export function diffSchemas(left, right, a = "left", b = "right") {
  const out = [];
  const keys = (x, y) => [...new Set([...Object.keys(x ?? {}), ...Object.keys(y ?? {})])].sort();
  const same = (x, y) => JSON.stringify(x) === JSON.stringify(y);

  for (const t of keys(left.tables, right.tables)) {
    const L = left.tables[t];
    const R = right.tables[t];
    if (!L) { out.push(`table ${t}: only in ${b}`); continue; }
    if (!R) { out.push(`table ${t}: only in ${a}`); continue; }
    const singular = { columns: "column", constraints: "constraint", indexes: "index", triggers: "trigger" };
    for (const part of Object.keys(singular)) {
      const what = singular[part];
      for (const n of keys(L[part], R[part])) {
        const l = L[part][n];
        const r = R[part][n];
        if (l === undefined) out.push(`table ${t}: ${what} ${n} only in ${b}: ${fmt(r)}`);
        else if (r === undefined) out.push(`table ${t}: ${what} ${n} only in ${a}: ${fmt(l)}`);
        else if (!same(stripPos(l), stripPos(r))) out.push(`table ${t}: ${what} ${n} differs: ${a}=${fmt(l)} ${b}=${fmt(r)}`);
      }
    }
    if (!same(L.view, R.view)) out.push(`view ${t}: definition differs`);
  }
  for (const part of ["sequences", "functions", "enums"]) {
    for (const n of keys(left[part], right[part])) {
      const l = left[part][n];
      const r = right[part][n];
      if (l === undefined) out.push(`${part.slice(0, -1)} ${n}: only in ${b}`);
      else if (r === undefined) out.push(`${part.slice(0, -1)} ${n}: only in ${a}`);
      else if (!same(l, r)) out.push(`${part.slice(0, -1)} ${n}: differs`);
    }
  }
  return out;
}

// Column position differs harmlessly when columns were added in a different order.
function stripPos(v) {
  if (v && typeof v === "object" && "pos" in v) {
    const { pos, ...rest } = v;
    return rest;
  }
  return v;
}

function fmt(v) {
  if (typeof v === "string") return v;
  const x = stripPos(v);
  if (x && x.type && "not_null" in x) {
    return `${x.type}${x.not_null ? " NOT NULL" : ""}${x.default ? ` DEFAULT ${x.default}` : ""}${x.identity ? ` IDENTITY(${x.identity})` : ""}`;
  }
  return x?.def ?? JSON.stringify(x);
}
